"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ShieldAlert, Terminal, Activity, Network, ShieldCheck, Play, RotateCcw, Cpu, Server } from "lucide-react"
import { LineChart, Line, ResponsiveContainer, AreaChart, Area } from "recharts"

const INITIAL_ARP_TABLE = [
  { ip: "192.168.1.1", mac: "00:50:56:C0:00:01", type: "Gateway" },
  { ip: "192.168.1.10", mac: "08:00:27:A1:B2:C3", type: "Victim (Ubuntu)" },
  { ip: "192.168.1.50", mac: "08:00:27:F4:E5:D6", type: "Attacker (Kali)" },
]

const GENERATED_TRAFFIC = Array.from({ length: 20 }, (_, i) => ({
  time: i,
  packets: Math.floor(Math.random() * 50) + 10,
  latency: Math.floor(Math.random() * 5) + 2,
}))

export function SimulationDashboard() {
  const [isSpoofing, setIsSpoofing] = useState(false)
  const [arpTable, setArpTable] = useState(INITIAL_ARP_TABLE)
  const [logs, setLogs] = useState<string[]>([
    "[SYSTEM] Environment initialized.",
    "[SYSTEM] Network interface eth0 up.",
    "[SYSTEM] Monitoring ARP traffic...",
  ])
  const [trafficData, setTrafficData] = useState(GENERATED_TRAFFIC)

  const addLog = (msg: string) => {
    setLogs((prev) => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev].slice(0, 10))
  }

  const toggleSpoofing = () => {
    if (!isSpoofing) {
      setIsSpoofing(true)
      addLog("ATTACK STARTED: Sending forged ARP replies...")
      addLog("KALI -> UBUNTU: '192.168.1.1 is at 08:00:27:F4:E5:D6'")

      // Update ARP table to show success
      setTimeout(() => {
        setArpTable((prev) =>
          prev.map((row) =>
            row.ip === "192.168.1.1"
              ? { ...row, mac: "08:00:27:F4:E5:D6" } // Attacker MAC
              : row,
          ),
        )
        addLog("CONFIRMED: Victim ARP table poisoned.")
      }, 1500)
    } else {
      setIsSpoofing(false)
      setArpTable(INITIAL_ARP_TABLE)
      addLog("ATTACK STOPPED: Restoring network state.")
    }
  }

  // Simulate real-time data
  useEffect(() => {
    const interval = setInterval(() => {
      setTrafficData((prev) => {
        const next = [
          ...prev.slice(1),
          {
            time: prev[prev.length - 1].time + 1,
            packets: isSpoofing ? Math.floor(Math.random() * 100) + 150 : Math.floor(Math.random() * 50) + 10,
            latency: isSpoofing ? Math.floor(Math.random() * 20) + 15 : Math.floor(Math.random() * 5) + 2,
          },
        ]
        return next
      })
    }, 2000)
    return () => clearInterval(interval)
  }, [isSpoofing])

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header - Inspired by OpenAI/Vercel styling */}
      <header className="border-b bg-background/50 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-xl font-bold tracking-tight">ARP Poisoning Lab v1.0</h1>
              <p className="text-xs text-muted-foreground uppercase tracking-widest">MITM Attack Simulation</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant={isSpoofing ? "destructive" : "secondary"} className="px-3 py-1">
              {isSpoofing ? "Attack Active" : "Monitoring Mode"}
            </Badge>
            <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset Lab
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Attack Controls & Theory */}
          <div className="lg:col-span-4 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="w-5 h-5 text-primary" />
                  Control Panel
                </CardTitle>
                <CardDescription>Execute or stop the ARP spoofing attack</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-muted rounded-lg border flex flex-col items-center text-center">
                  <Activity
                    className={`w-12 h-12 mb-3 ${isSpoofing ? "text-destructive animate-pulse" : "text-muted-foreground"}`}
                  />
                  <h3 className="font-semibold">{isSpoofing ? "Packet Injection Active" : "System Idle"}</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {isSpoofing
                      ? "Forged ARP replies are being broadcast to the target."
                      : "The network is operating under normal protocol conditions."}
                  </p>
                </div>
                <Button
                  className="w-full h-12 text-lg font-semibold"
                  variant={isSpoofing ? "destructive" : "default"}
                  onClick={toggleSpoofing}
                >
                  {isSpoofing ? "Terminate Attack" : "Launch Spoofing Attack"}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm uppercase tracking-wider text-muted-foreground">Attack Logic</CardTitle>
              </CardHeader>
              <CardContent className="text-sm space-y-4">
                <div className="flex items-start gap-3">
                  <div className="mt-1 bg-primary/20 p-1 rounded">
                    <Network className="w-4 h-4 text-primary" />
                  </div>
                  <p>
                    <strong>Goal:</strong> Intercept traffic between Victim (Ubuntu) and Gateway.
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1 bg-primary/20 p-1 rounded">
                    <Cpu className="w-4 h-4 text-primary" />
                  </div>
                  <p>
                    <strong>Mechanism:</strong> Send gratituitous ARP replies telling the Victim that the Gateway IP is
                    at the Attacker's MAC address.
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1 bg-primary/20 p-1 rounded">
                    <ShieldAlert className="w-4 h-4 text-primary" />
                  </div>
                  <p>
                    <strong>Vulnerability:</strong> ARP is stateless and trusts replies without checking for requests.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Observability & Tables */}
          <div className="lg:col-span-8 space-y-6">
            {/* Real-time Observability - Inspired by Vercel Dashboard */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center justify-between">
                    Network Throughput
                    <span className="text-xs text-muted-foreground">Packets/sec</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={trafficData}>
                      <defs>
                        <linearGradient id="colorPackets" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={isSpoofing ? "#ef4444" : "#3b82f6"} stopOpacity={0.3} />
                          <stop offset="95%" stopColor={isSpoofing ? "#ef4444" : "#3b82f6"} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <Area
                        type="monotone"
                        dataKey="packets"
                        stroke={isSpoofing ? "#ef4444" : "#3b82f6"}
                        fillOpacity={1}
                        fill="url(#colorPackets)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center justify-between">
                    Network Latency
                    <span className="text-xs text-muted-foreground">ms</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={trafficData}>
                      <Line
                        type="monotone"
                        dataKey="latency"
                        stroke={isSpoofing ? "#f59e0b" : "#10b981"}
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Tabs defaultValue="arp-table" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="arp-table">Victim ARP Cache</TabsTrigger>
                <TabsTrigger value="terminal">Attacker Console</TabsTrigger>
              </TabsList>

              <TabsContent value="arp-table">
                <Card>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs uppercase bg-muted/50 border-b">
                          <tr>
                            <th className="px-6 py-4 font-medium">IP Address</th>
                            <th className="px-6 py-4 font-medium">MAC Address</th>
                            <th className="px-6 py-4 font-medium">Interface Type</th>
                            <th className="px-6 py-4 font-medium">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                          {arpTable.map((row, i) => (
                            <tr key={i} className="hover:bg-muted/30 transition-colors">
                              <td className="px-6 py-4 font-mono">{row.ip}</td>
                              <td
                                className={`px-6 py-4 font-mono ${isSpoofing && row.ip === "192.168.1.1" ? "text-destructive font-bold" : ""}`}
                              >
                                {row.mac}
                              </td>
                              <td className="px-6 py-4 text-muted-foreground">{row.type}</td>
                              <td className="px-6 py-4">
                                {isSpoofing && row.mac === "08:00:27:F4:E5:D6" && row.ip !== "192.168.1.50" ? (
                                  <Badge variant="destructive">POISONED</Badge>
                                ) : (
                                  <Badge variant="outline">Verified</Badge>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
                <div className="mt-4 p-4 border rounded-lg bg-primary/5 text-sm text-primary flex items-center gap-3">
                  <ShieldCheck className="w-5 h-5 shrink-0" />
                  <p>
                    <strong>Analysis:</strong> Note how 192.168.1.1 and 192.168.1.50 now share the same MAC address.
                    This confirms the MITM position.
                  </p>
                </div>
              </TabsContent>

              <TabsContent value="terminal">
                <Card className="bg-[#0c0c0c] border-muted overflow-hidden">
                  <div className="bg-muted px-4 py-2 flex items-center gap-2 border-b">
                    <Terminal className="w-4 h-4" />
                    <span className="text-xs font-mono">root@kali:~# arpspoof -i eth0 -t 192.168.1.10 192.168.1.1</span>
                  </div>
                  <CardContent className="p-4 h-[300px] overflow-y-auto font-mono text-sm">
                    {logs.map((log, i) => (
                      <div key={i} className="mb-1">
                        <span className="text-primary mr-2 opacity-50">{">"}</span>
                        <span
                          className={
                            log.includes("ATTACK")
                              ? "text-destructive"
                              : log.includes("CONFIRMED")
                                ? "text-green-500"
                                : "text-foreground"
                          }
                        >
                          {log}
                        </span>
                      </div>
                    ))}
                    {isSpoofing && (
                      <div className="animate-pulse">
                        <span className="text-primary mr-2 opacity-50">{">"}</span>
                        Injecting packets...
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>

      <footer className="border-t py-8 mt-auto">
        <div className="container mx-auto px-6 text-center text-sm text-muted-foreground">
          <p>Cybersecurity Lab: Address Resolution Protocol (ARP) Vulnerability Analysis</p>
          <div className="flex justify-center gap-6 mt-4">
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4" />
              <span>Attacker: Kali Linux</span>
            </div>
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4" />
              <span>Victim: Ubuntu Linux</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
