import { SimulationDashboard } from "@/components/simulation-dashboard"

export default function Home() {
  return <SimulationDashboard />
}
